import sys
import os
import json

# Add backend to path
sys.path.append(os.path.dirname(__file__))

import database, models, utils
from sqlalchemy.orm import Session

def test_usage():
    db = next(database.get_db())
    
    # 1. Ensure we have a test firm
    firm = db.query(models.Firm).filter(models.Firm.slug == "test-firm").first()
    if not firm:
        firm = models.Firm(
            name="Test Firm",
            slug="test-firm",
            api_config_json=json.dumps({
                "stripe_customer_id": "cus_test_123",
                "stripe_usage_subscription_item_id": "si_test_123"
            })
        )
        db.add(firm)
        db.commit()
        db.refresh(firm)
        print(f"Created test firm: {firm.id}")
    else:
        print(f"Using existing test firm: {firm.id}")
        
    # 2. Log usage
    utils.log_usage(db, firm.id, "document_analysis", quantity=1.0, details="Test usage logging")
    print("Usage logged successfully.")
    
    # 3. Verify in DB
    usage = db.query(models.Usage).filter(models.Usage.firm_id == firm.id).order_by(models.Usage.id.desc()).first()
    if usage:
        print(f"Found usage in DB: {usage.id}, {usage.usage_type}, {usage.quantity}")
    else:
        print("Usage not found in DB!")

if __name__ == "__main__":
    test_usage()
