import models
from database import engine
from sqlalchemy import inspect

print("Tables before:")
inspector = inspect(engine)
print(inspector.get_table_names())

print("Running create_all...")
models.Base.metadata.create_all(bind=engine)

print("Tables after:")
print(inspect(engine).get_table_names())
