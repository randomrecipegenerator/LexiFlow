import os
import sys
import json
from dotenv import load_dotenv

# Add backend to path
sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from stripe_engine import stripe_engine

def setup():
    load_dotenv()
    api_key = os.getenv("STRIPE_SECRET_KEY")
    if not api_key:
        print("Error: STRIPE_SECRET_KEY not found in .env")
        return

    print(f"Using Stripe Key: {api_key[:8]}...")
    
    products = stripe_engine.create_products()
    
    print("\nStripe Products & Prices Created/Verified:")
    print(json.dumps(products, indent=2))
    
    # Optionally save these to a config file for the app to use
    config_path = os.path.join(os.path.dirname(__file__), "..", "stripe_config.json")
    with open(config_path, "w") as f:
        json.dump(products, f, indent=2)
    print(f"\nPrice IDs saved to {config_path}")

if __name__ == "__main__":
    setup()
