import httpx
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

class FilevineSync:
    def __init__(self, api_key: str, config: Dict[str, Any] = None):
        self.api_key = api_key
        self.config = config or {}
        self.base_url = "https://api.filevine.io"
        self.leaddock_base_url = "https://api.leaddock.com"

    def map_lead_data(self, lead_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Maps LexiFlow lead data to Filevine/LeadDock fields.
        """
        name_parts = lead_data.get("full_name", "Anonymous Lead").split(" ", 1)
        first_name = name_parts[0]
        last_name = name_parts[1] if len(name_parts) > 1 else "Lead"

        return {
            "firstName": first_name,
            "lastName": last_name,
            "email": lead_data.get("email"),
            "phone": lead_data.get("phone"),
            "notes": f"AI Summary: {lead_data.get('ai_summary')}\nQualification Score: {lead_data.get('score')}",
            "source": "LexiFlow AI",
            "projectName": f"{first_name} {last_name} - {lead_data.get('case_type', 'Intake')}"
        }

    async def sync_lead(self, lead_data: Dict[str, Any]) -> Dict[str, Any]:
        mapped_data = self.map_lead_data(lead_data)
        session_id = self.config.get("session_id")
        
        async with httpx.AsyncClient() as client:
            try:
                if session_id:
                    # Direct Filevine Project creation
                    response = await client.post(
                        f"{self.base_url}/projects",
                        json=mapped_data,
                        headers={
                            "x-fv-apikey": self.api_key,
                            "x-fv-sessionid": session_id
                        }
                    )
                else:
                    # Default to LeadDock endpoint
                    response = await client.post(
                        f"{self.leaddock_base_url}/leads",
                        json=mapped_data,
                        headers={"x-api-key": self.api_key}
                    )
                
                if response.status_code in [200, 201]:
                    data = response.json()
                    return {"status": "success", "external_id": str(data.get("id") or data.get("projectId"))}
                else:
                    logger.error(f"Filevine Sync Error: {response.status_code} - {response.text}")
                    return {"status": "error", "message": f"Filevine API error: {response.status_code}"}
            except Exception as e:
                logger.error(f"Filevine Connection Exception: {str(e)}")
                return {"status": "error", "message": str(e)}
