import httpx
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

class ClioSync:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://grow.clio.com/api/v1"

    def map_lead_data(self, lead_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Maps LexiFlow lead data to Clio Grow (Lexicata) fields.
        """
        name_parts = lead_data.get("full_name", "Anonymous Lead").split(" ", 1)
        first_name = name_parts[0]
        last_name = name_parts[1] if len(name_parts) > 1 else "Lead"

        return {
            "from_first": first_name,
            "from_last": last_name,
            "from_email": lead_data.get("email"),
            "from_phone": lead_data.get("phone"),
            "from_message": f"AI Summary: {lead_data.get('ai_summary')}\nQualification Score: {lead_data.get('score')}",
            "referring_url": "LexiFlow AI Sync"
        }

    async def sync_lead(self, lead_data: Dict[str, Any]) -> Dict[str, Any]:
        mapped_data = self.map_lead_data(lead_data)
        payload = {
            "auth_token": self.api_key,
            "inbox_lead": mapped_data
        }

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/inbox_leads",
                    json=payload
                )
                if response.status_code in [200, 201]:
                    data = response.json()
                    return {"status": "success", "external_id": data.get("id")}
                else:
                    logger.error(f"Clio Sync Error: {response.status_code} - {response.text}")
                    return {"status": "error", "message": f"Clio API error: {response.status_code}"}
            except Exception as e:
                logger.error(f"Clio Connection Exception: {str(e)}")
                return {"status": "error", "message": str(e)}
