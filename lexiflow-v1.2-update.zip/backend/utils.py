from sqlalchemy.orm import Session
import models
import datetime

import json
import stripe_engine

def log_usage(db: Session, firm_id: int, usage_type: str, quantity: float = 1.0, details: str = None):
    """
    Log usage for a firm and report to Stripe if configured.
    usage_type: document_analysis, voice_minutes, email_intake
    """
    if firm_id is None:
        return
        
    usage = models.Usage(
        firm_id=firm_id,
        usage_type=usage_type,
        quantity=quantity,
        details=details,
        timestamp=datetime.datetime.utcnow()
    )
    db.add(usage)
    db.commit()

    # Report to Stripe if configured
    firm = db.query(models.Firm).filter(models.Firm.id == firm_id).first()
    if firm and firm.api_config_json:
        try:
            config = json.loads(firm.api_config_json)
            customer_id = config.get("stripe_customer_id")
            # We need the specific subscription item ID for metered usage
            # In a real app, we might store this mapping in the DB.
            # For LexiFlow, we'll look for 'stripe_usage_subscription_item_id'
            sub_item_id = config.get("stripe_usage_subscription_item_id")
            
            if customer_id and sub_item_id and usage_type == "document_analysis":
                stripe_engine.stripe_engine.report_usage(customer_id, sub_item_id, int(quantity))
        except Exception as e:
            print(f"Error reporting Stripe usage: {e}")
