import os
import json
import httpx
import logging
from typing import Dict, Any, Optional

from integrations.clio_sync import ClioSync
from integrations.filevine_sync import FilevineSync
try:
    from . import models
    from .database import SessionLocal
except ImportError:
    import models
    from database import SessionLocal


logger = logging.getLogger(__name__)

class IntegrationEngine:
    def __init__(self):
        pass

    async def sync_lead(self, lead, system: str) -> Dict[str, Any]:
        firm = lead.firm
        db = SessionLocal()
        
        try:
            # 1. Check for dedicated FirmIntegration record
            integration = db.query(models.FirmIntegration).filter(
                models.FirmIntegration.firm_id == firm.id,
                models.FirmIntegration.crm_system == system,
                models.FirmIntegration.is_active == 1
            ).first()

            # 2. Map lead data
            lead_data = {
                "full_name": lead.full_name,
                "email": lead.email,
                "phone": lead.phone,
                "case_type": lead.case_type,
                "ai_summary": lead.ai_summary,
                "score": lead.qualification_score
            }

            # 3. Determine if we are in Production or Simulation mode
            production_mode = firm.production_sync_enabled if firm else False
            
            if not production_mode:
                logger.info(f"SIMULATION: Syncing lead {lead.id} to {system}")
                return {
                    "status": "success",
                    "message": f"Successfully mapped and synced to {system.capitalize()} (Simulation)",
                    "simulated": True,
                    "payload": lead_data
                }

            # Production Sync Logic
            if system == "clio":
                api_key = integration.api_key if integration else None
                if not api_key and firm.api_config_json:
                    config = json.loads(firm.api_config_json)
                    api_key = config.get("clio_auth_token") or config.get("lexicata_auth_token")
                
                if not api_key:
                    return {"status": "error", "message": "Clio API Key not configured."}
                
                client = ClioSync(api_key)
                return await client.sync_lead(lead_data)

            elif system == "filevine":
                api_key = integration.api_key if integration else None
                config = {}
                if integration and integration.config_json:
                    config = json.loads(integration.config_json)
                
                if not api_key and firm.api_config_json:
                    firm_config = json.loads(firm.api_config_json)
                    api_key = firm_config.get("filevine_api_key")
                    config["session_id"] = firm_config.get("filevine_session_id")

                if not api_key:
                    return {"status": "error", "message": "Filevine API Key not configured."}

                client = FilevineSync(api_key, config)
                return await client.sync_lead(lead_data)
            
            else:
                return {"status": "error", "message": f"Integration with {system} not supported."}

        finally:
            db.close()

    async def send_postmark_email(self, to_email: str, subject: str, body: str, firm=None) -> Dict[str, Any]:
        """Send an outbound email via Postmark API."""
        api_key = None
        if firm and firm.api_config_json:
            try:
                config = json.loads(firm.api_config_json)
                api_key = config.get("postmark_api_key")
            except:
                pass
        
        if not api_key:
            api_key = os.getenv("POSTMARK_SERVER_TOKEN")

        from_email = os.getenv("POSTMARK_FROM_EMAIL", "intake@lexiflow.co")
        
        if not api_key or "placeholder" in api_key.lower():
            logger.info(f"SIMULATED EMAIL to {to_email}: {subject}")
            return {"status": "success", "simulated": True}

        payload = {
            "From": from_email,
            "To": to_email,
            "Subject": subject,
            "TextBody": body,
            "MessageStream": "outbound"
        }

        async with httpx.AsyncClient() as client:
            try:
                res = await client.post(
                    "https://api.postmarkapp.com/email",
                    json=payload,
                    headers={
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "X-Postmark-Server-Token": api_key
                    }
                )
                return res.json()
            except Exception as e:
                logger.error(f"Postmark send failed: {str(e)}")
                return {"status": "error", "message": str(e)}

    async def push_to_github(self, firm, repo_full_name: str, branch: str, file_path: str, content: str, commit_message: str) -> Dict[str, Any]:
        """
        Push content to a GitHub repository.
        repo_full_name: e.g. "owner/repo"
        """
        config = {}
        if firm and firm.api_config_json:
            try:
                config = json.loads(firm.api_config_json)
            except:
                pass
        
        github_token = config.get("github_token") or os.getenv("GITHUB_TOKEN")
        
        if not github_token:
            return {"status": "error", "message": "GitHub token not configured for this firm."}
            
        async with httpx.AsyncClient() as client:
            try:
                # 1. Get the current file (to get SHA if it exists)
                headers = {
                    "Authorization": f"token {github_token}",
                    "Accept": "application/vnd.github.v3+json"
                }
                
                url = f"https://api.github.com/repos/{repo_full_name}/contents/{file_path}"
                params = {"ref": branch}
                
                res = await client.get(url, headers=headers, params=params)
                sha = None
                if res.status_code == 200:
                    sha = res.json().get("sha")
                
                # 2. Push content
                import base64
                encoded_content = base64.b64encode(content.encode()).decode()
                
                payload = {
                    "message": commit_message,
                    "content": encoded_content,
                    "branch": branch
                }
                if sha:
                    payload["sha"] = sha
                    
                res = await client.put(url, headers=headers, json=payload)
                
                if res.status_code in [200, 201]:
                    return {"status": "success", "url": res.json().get("content", {}).get("html_url")}
                else:
                    logger.error(f"GitHub Push Error: {res.status_code} - {res.text}")
                    return {"status": "error", "message": f"GitHub API error: {res.status_code}", "details": res.text}
            except Exception as e:
                logger.error(f"GitHub Connection Exception: {str(e)}")
                return {"status": "error", "message": str(e)}

    async def trigger_auto_sync(self, lead, db: SessionLocal):
        """
        Check for active integrations with auto-sync enabled and trigger them.
        """
        if not lead.firm_id:
            return

        integrations = db.query(models.FirmIntegration).filter(
            models.FirmIntegration.firm_id == lead.firm_id,
            models.FirmIntegration.is_active == 1,
            models.FirmIntegration.auto_sync_enabled == 1
        ).all()

        for integration in integrations:
            try:
                result = await self.sync_lead(lead, integration.crm_system)
                if result["status"] == "success":
                    lead.sync_status = f"Auto-Synced ({integration.crm_system.capitalize()})"
                    if "external_id" in result:
                        lead.external_crm_id = result["external_id"]
                    elif result.get("simulated"):
                         import uuid
                         lead.external_crm_id = f"auto_sim_{uuid.uuid4().hex[:8]}"
                    db.commit()
                    # Audit log creation should ideally be handled here too, 
                    # but we need to pass a way to create it or import it.
                    # For now, we'll just log it.
                    logger.info(f"Auto-sync successful for lead {lead.id} to {integration.crm_system}")
                else:
                    logger.error(f"Auto-sync failed for lead {lead.id} to {integration.crm_system}: {result.get('message')}")
            except Exception as e:
                logger.error(f"Auto-Sync Exception ({integration.crm_system}): {e}")

integration_engine = IntegrationEngine()

