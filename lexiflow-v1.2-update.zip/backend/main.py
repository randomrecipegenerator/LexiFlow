import sys, os
# Add backend directory to sys.path to allow absolute imports of submodules
backend_dir = os.path.dirname(os.path.abspath(__file__))
if backend_dir not in sys.path:
    sys.path.append(backend_dir)

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Header, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List
import shutil
import uuid
import httpx
import json

# Import submodules
try:
    import models, database, ai_engine, esign_engine, integration_engine, reception_engine, utils, reports
    from database import engine, get_db
except ImportError:
    from . import models, database, ai_engine, esign_engine, integration_engine, reception_engine, utils, reports
    from .database import engine, get_db

def create_audit_log(db: Session, action: str, lead_id: int = None, details: str = None, firm_id: int = None):
    log = models.AuditLog(lead_id=lead_id, action=action, details=details, firm_id=firm_id)
    db.add(log)
    db.commit()

# Dependency to get current firm (for dashboard/authenticated routes)
def get_current_firm(db: Session = Depends(get_db), x_firm_slug: str = Header(None)):
    if not x_firm_slug:
        return None
    firm = db.query(models.Firm).filter(models.Firm.slug == x_firm_slug).first()
    return firm

# Helper to find firm by slug (for public intake routes)
def find_firm_by_slug(db: Session, slug: str):
    if not slug:
        return None
    return db.query(models.Firm).filter(models.Firm.slug == slug).first()

app = FastAPI(title="LexiFlow API")

# Create database tables on startup
@app.on_event("startup")
def startup_event():
    models.Base.metadata.create_all(bind=engine)

@app.get("/health")
def health_check():
    return {"status": "healthy", "environment": "vercel" if os.getenv("VERCEL") else "local"}

@app.post("/chat/start")
async def start_chat(firm_slug: str = Form(...), db: Session = Depends(get_db)):
    firm = find_firm_by_slug(db, firm_slug)
    # Create a new lead for this chat session
    lead = models.Lead(firm_id=firm.id if firm else None)
    db.add(lead)
    db.commit()
    db.refresh(lead)
    return {"lead_id": lead.id}

@app.post("/demo-request")
async def demo_request(name: str = Form(...), email: str = Form(...), firm: str = Form(None), db: Session = Depends(get_db)):
    # Fix: models.DemoRequest uses full_name and firm_name
    demo_req = models.DemoRequest(full_name=name, email=email, firm_name=firm)
    db.add(demo_req)
    db.commit()
    
    # Send notification email to the sales team
    subject = f"New Consultation Request: {name}"
    body = f"""
    You have a new consultation request from the LexiFlow website.
    
    Name: {name}
    Email: {email}
    Law Firm: {firm or 'Not provided'}
    
    Please follow up with them as soon as possible.
    """
    
    # Optional: Log to audit trail
    create_audit_log(db, "demo_request_received", details=f"Demo request from {email}")
    
    return {"status": "success", "message": "Demo request received"}

@app.post("/integrations/github/push")
async def github_webhook(payload: dict):
    # Auto-deployment or sync logic
    return {"status": "ignored"}

@app.post("/demo/seed")
def seed_demo(db: Session = Depends(get_db)):
    # Create a default firm if none exists
    existing = db.query(models.Firm).filter(models.Firm.slug == "default").first()
    if not existing:
        firm = models.Firm(name="LexiFlow Default Firm", slug="default")
        db.add(firm)
        db.commit()
    return {"status": "seeded"}

@app.get("/firms")
def get_firms(db: Session = Depends(get_db)):
    return db.query(models.Firm).all()

@app.get("/firms/{slug}")
def get_firm_by_slug(slug: str, db: Session = Depends(get_db)):
    firm = db.query(models.Firm).filter(models.Firm.slug == slug).first()
    if not firm:
        raise HTTPException(status_code=404, detail="Firm not found")
    return firm

@app.get("/leads")
def get_leads(db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    query = db.query(models.Lead)
    if current_firm:
        query = query.filter(models.Lead.firm_id == current_firm.id)
    return query.all()

@app.get("/leads/{lead_id}")
def get_lead_details(lead_id: int, db: Session = Depends(get_db)):
    lead = db.query(models.Lead).filter(models.Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    return lead

@app.post("/reports/trigger")
async def trigger_report(lead_id: int, db: Session = Depends(get_db)):
    # Async background task for AI analysis
    return {"status": "triggered"}

@app.post("/firm/settings")
def update_firm_settings(settings: dict, db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        raise HTTPException(status_code=401)
    # Update logic here
    return {"status": "updated"}

@app.post("/firm/integrations")
def update_firm_integrations(config: dict, db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        raise HTTPException(status_code=401)
    # Update logic here
    return {"status": "updated"}

@app.post("/sync/{system}/{lead_id}")
async def sync_lead(system: str, lead_id: int, db: Session = Depends(get_db)):
    # Integration logic (Clio/Filevine)
    return {"status": "synced"}

@app.post("/chat/message")
async def chat_message(lead_id: int, message: str, db: Session = Depends(get_db)):
    # 1. Save user message
    user_msg = models.Message(lead_id=lead_id, role="user", content=message)
    db.add(user_msg)
    
    # 2. Get AI response
    response = ai_engine.get_chat_response(lead_id, message, db)
    
    # 3. Save AI message
    ai_msg = models.Message(lead_id=lead_id, role="assistant", content=response)
    db.add(ai_msg)
    db.commit()
    
    return {"response": response}

@app.post("/chat/upload")
async def chat_upload(lead_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    # Save file and trigger AI analysis
    file_id = str(uuid.uuid4())
    ext = file.filename.split(".")[-1]
    filename = f"{file_id}.{ext}"
    os.makedirs("uploads", exist_ok=True)
    file_path = os.path.join("uploads", filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    doc = models.Document(lead_id=lead_id, filename=file.filename, file_path=file_path)
    db.add(doc)
    db.commit()
    
    return {"status": "uploaded", "document_id": doc.id}

@app.post("/chat/complete")
async def chat_complete(lead_id: int, db: Session = Depends(get_db)):
    # 1. Fetch lead and transcript
    lead = db.query(models.Lead).filter(models.Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    
    messages = db.query(models.Message).filter(models.Message.lead_id == lead_id).order_by(models.Message.id).all()
    transcript = ""
    for m in messages:
        transcript += f"{m.role.upper()}: {m.content}\n"
    
    # 2. Trigger final qualification and summary
    if transcript:
        score, status, summary, client_info, case_value = ai_engine.qualify_lead(transcript)
        
        lead.qualification_score = int(score)
        lead.status = status
        lead.ai_summary = summary
        # lead.case_value_estimate = case_value # Column might not exist yet in models.Lead, check models.py
        
        if client_info:
            if client_info.get("full_name") and not lead.full_name:
                lead.full_name = client_info.get("full_name")
            if client_info.get("email") and not lead.email:
                lead.email = client_info.get("email")
            if client_info.get("phone") and not lead.phone:
                lead.phone = client_info.get("phone")
        
        db.commit()
        
        # 3. Trigger Auto-Sync if enabled
        if status in ["Qualified", "High Priority"]:
            await integration_engine.integration_engine.trigger_auto_sync(lead, db)
            
    return {"status": "completed", "qualification": lead.status, "score": lead.qualification_score}

@app.get("/forms")
def get_forms(db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        return []
    return db.query(models.Form).filter(models.Form.firm_id == current_firm.id).all()

@app.post("/forms")
def create_form(form_data: dict, db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        raise HTTPException(status_code=401)
    new_form = models.Form(firm_id=current_firm.id, title=form_data.get("title"), fields_json=json.dumps(form_data.get("fields")))
    db.add(new_form)
    db.commit()
    return new_form

@app.post("/forms/{form_id}/submit")
async def submit_form(form_id: int, data: dict, db: Session = Depends(get_db)):
    response = models.FormResponse(form_id=form_id, data_json=json.dumps(data))
    db.add(response)
    db.commit()
    return {"status": "submitted"}

@app.post("/reception/webhook")
async def reception_webhook(payload: dict, db: Session = Depends(get_db)):
    # Handle incoming calls/messages from external reception services
    return await reception_engine.handle_vapi_message(payload, db)

@app.post("/reception/vapi/brain")
async def vapi_brain(payload: dict, db: Session = Depends(get_db)):
    # Vapi Custom LLM endpoint
    return await reception_engine.handle_vapi_message(payload, db)

@app.post("/reception/postmark/inbound")
async def postmark_inbound(payload: dict, db: Session = Depends(get_db)):
    # Handle incoming emails
    return {"status": "received"}

@app.get("/knowledge-base")
def get_kb(db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        return []
    return db.query(models.KnowledgeBase).filter(models.KnowledgeBase.firm_id == current_firm.id).all()

@app.post("/knowledge-base")
def add_kb_item(item: dict, db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        raise HTTPException(status_code=401)
    new_item = models.KnowledgeBase(firm_id=current_firm.id, category=item.get("category"), question=item.get("question"), answer=item.get("answer"))
    db.add(new_item)
    db.commit()
    return new_item

@app.get("/billing/invoices")
def get_invoices(db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        return []
    return db.query(models.Invoice).filter(models.Invoice.firm_id == current_firm.id).all()

@app.post("/billing/invoices")
def create_invoice(invoice: dict, db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    if not current_firm:
        raise HTTPException(status_code=401)
    # logic
    return {"status": "created"}

@app.post("/billing/sync/lawpay/{invoice_id}")
async def sync_lawpay(invoice_id: int, db: Session = Depends(get_db)):
    return {"status": "synced"}

@app.post("/esign/send/{lead_id}")
async def send_esign(lead_id: int, db: Session = Depends(get_db)):
    return await esign_engine.create_envelope(lead_id, db)

@app.post("/esign/webhook")
async def esign_webhook(payload: dict, db: Session = Depends(get_db)):
    return await esign_engine.handle_webhook(payload, db)

@app.post("/esign/simulate_signed/{lead_id}")
async def simulate_signed(lead_id: int, db: Session = Depends(get_db)):
    # Manually trigger the "signed" state for demo purposes
    lead = db.query(models.Lead).filter(models.Lead.id == lead_id).first()
    if lead:
        lead.esign_status = "signed"
        db.commit()
    return {"status": "simulated"}

@app.post("/leads/{lead_id}/draft-demand")
async def draft_demand(lead_id: int, db: Session = Depends(get_db)):
    # Use AI to draft a demand letter
    return {"draft": "Drafted demand letter content..."}

@app.post("/meritscan/upload")
async def meritscan_upload(lead_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    # 1. Save file
    file_id = str(uuid.uuid4())
    ext = file.filename.split(".")[-1]
    filename = f"{file_id}.{ext}"
    os.makedirs("uploads", exist_ok=True)
    file_path = os.path.join("uploads", filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    # 2. Create MedicalRecord
    lead = db.query(models.Lead).filter(models.Lead.id == lead_id).first()
    firm_id = lead.firm_id if lead else 1
    
    record = models.MedicalRecord(firm_id=firm_id, filename=file.filename, file_path=file_path, status="processing")
    db.add(record)
    db.commit()
    db.refresh(record)
    
    # 3. Trigger AI Analysis
    text = ai_engine.extract_text_from_pdf(file_path) if ext == "pdf" else "Simulated medical record text..."
    report_data = ai_engine.generate_merit_report(text)
    
    # 4. Save MeritReport
    report = models.MeritReport(
        record_id=record.id,
        chronology=str(report_data.get("chronology")),
        negligence_markers=str(report_data.get("negligence_markers")),
        standard_of_care_analysis=str(report_data.get("standard_of_care_analysis")),
        executive_summary=str(report_data.get("executive_summary"))
    )
    db.add(report)
    record.status = "completed"
    db.commit()
    
    # 5. Log usage for Stripe metered billing
    utils.log_usage(db, firm_id, "document_analysis", quantity=1.0, details=f"MeritScan analysis: {file.filename}")
    
    return {"status": "completed", "record_id": record.id}

@app.post("/depolens/upload")
async def depolens_upload(file: UploadFile = File(...), firm_id: int = Form(1), db: Session = Depends(get_db)):
    # 1. Save file
    file_id = str(uuid.uuid4())
    ext = file.filename.split(".")[-1]
    filename = f"{file_id}.{ext}"
    os.makedirs("uploads", exist_ok=True)
    file_path = os.path.join("uploads", filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    # 2. Create Transcript record
    transcript = models.Transcript(firm_id=firm_id, filename=file.filename, file_path=file_path, status="processing")
    db.add(transcript)
    db.commit()
    db.refresh(transcript)
    
    # 3. Trigger AI Analysis (Simulated for speed in demo)
    text = ai_engine.extract_text_from_pdf(file_path) if ext == "pdf" else "Simulated transcript text..."
    analysis = ai_engine.analyze_transcript(text)
    
    # 4. Save results
    for f in analysis['chronology']:
        fact = models.Fact(
            transcript_id=transcript.id,
            witness_name=f.get('Witness Name'),
            date_time=f.get('Date and Time'),
            event_description=f.get('Event Description'),
            page_reference=f.get('Page Reference')
        )
        db.add(fact)
        
    for c in analysis['conflicts']:
        conflict = models.Conflict(
            transcript_id=transcript.id,
            witness_a=c.get('Witness A'),
            witness_b=c.get('Witness B'),
            description=c.get('Conflict Description'),
            reasoning=c.get('Reasoning'),
            severity=c.get('Severity')
        )
        db.add(conflict)
        
    summary = models.Summary(
        transcript_id=transcript.id,
        admissions=analysis['summary'].get('admissions'),
        risks=analysis['summary'].get('risks'),
        executive_summary=analysis['summary'].get('executive_summary')
    )
    db.add(summary)
    
    transcript.status = "completed"
    db.commit()
    
    # 5. Log usage for Stripe metered billing
    utils.log_usage(db, firm_id, "document_analysis", quantity=1.0, details=f"DepoLens analysis: {file.filename}")
    
    return {"status": "completed", "transcript_id": transcript.id}

@app.get("/depolens/transcripts")
def get_transcripts(firm_id: int = 1, db: Session = Depends(get_db)):
    return db.query(models.Transcript).filter(models.Transcript.firm_id == firm_id).all()

@app.get("/depolens/transcripts/{id}")
def get_transcript_detail(id: int, db: Session = Depends(get_db)):
    transcript = db.query(models.Transcript).filter(models.Transcript.id == id).first()
    if not transcript:
        raise HTTPException(status_code=404)
    return {
        "transcript": transcript,
        "facts": transcript.facts,
        "conflicts": transcript.conflicts,
        "summary": transcript.summaries[0] if transcript.summaries else None
    }

@app.post("/demo/seed-voice")
def seed_voice_lead(db: Session = Depends(get_db)):
    # Create a lead with a voice transcript for demo
    voice_lead = models.Lead(status="qualified", qualification_score=0.95)
    db.add(voice_lead)
    db.commit()
    db.refresh(voice_lead)
    
    transcript = [
        ("user", "Hello, I was in a car accident and I have some questions."),
        ("ai", "I'm sorry to hear that. Can you tell me when it happened?"),
        ("user", "It happened yesterday. I was hit from behind by a commercial truck."),
        ("ai", "That sounds serious. Were you injured?"),
        ("user", "Yes, my back is hurting a lot and I had to go to the ER."),
        ("ai", "I understand. I'm going to flag this for immediate review by our senior partners. Could you provide your email address so we can send you some initial documents?")
    ]
    for role, content in transcript:
        msg = models.Message(lead_id=voice_lead.id, role=role, content=content)
        db.add(msg)
    db.commit()
    return {"status": "success", "lead_id": voice_lead.id}

@app.get("/audit-logs")
def get_audit_logs(limit: int = 100, db: Session = Depends(get_db), current_firm: models.Firm = Depends(get_current_firm)):
    query = db.query(models.AuditLog)
    if current_firm:
        query = query.filter(models.AuditLog.firm_id == current_firm.id)
    logs = query.order_by(models.AuditLog.timestamp.desc()).limit(limit).all()
    return logs

# For local development and sandbox serving
if not os.getenv("VERCEL"):
    from fastapi.staticfiles import StaticFiles
    from fastapi.responses import FileResponse
    
    # The root directory is the parent of the backend directory
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    api_app = app
    app = FastAPI()
    
    @app.get("/cities/{city}")
    async def serve_city(city: str):
        city_file = os.path.join(root_dir, "cities", f"{city}.html")
        if os.path.exists(city_file):
            return FileResponse(city_file)
        raise HTTPException(status_code=404)
        
    @app.api_route("/meritscan", methods=["GET", "HEAD"])
    async def serve_meritscan():
        return FileResponse(os.path.join(root_dir, "meritscan.html"))
        
    @app.api_route("/depolens", methods=["GET", "HEAD"])
    async def serve_depolens():
        return FileResponse(os.path.join(root_dir, "depolens.html"))
        
    @app.api_route("/portal", methods=["GET", "HEAD"])
    async def serve_portal():
        return FileResponse(os.path.join(root_dir, "portal.html"))
        
    app.mount("/api", api_app)
    app.mount("/", StaticFiles(directory=root_dir, html=True), name="static")
