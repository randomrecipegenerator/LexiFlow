import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, Float, ForeignKey
from sqlalchemy.orm import relationship
try:
    from .database import Base
except ImportError:
    from database import Base

class Firm(Base):
    __tablename__ = "firms"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    slug = Column(String, unique=True, index=True)
    branding_logo = Column(String, nullable=True)
    branding_colors = Column(Text, nullable=True) # JSON of colors
    api_config_json = Column(Text, nullable=True) # Store Clio/Filevine/OpenAI keys per firm
    
    # AI Front Desk Settings
    voice_enabled = Column(Integer, default=1)
    voice_config_json = Column(Text, nullable=True) # voice_id, greeting, etc.
    email_enabled = Column(Integer, default=1)
    email_config_json = Column(Text, nullable=True) # template, inbound_address, etc.
    active_hours_json = Column(Text, nullable=True) # Monday: 9-5, etc.

    # CRM Settings
    production_sync_enabled = Column(Integer, default=0) # 0 for simulation, 1 for production

    users = relationship("User", back_populates="firm")
    leads = relationship("Lead", back_populates="firm")
    usage = relationship("Usage", back_populates="firm")

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    full_name = Column(String)
    role = Column(String) # admin, attorney, staff
    firm_id = Column(Integer, ForeignKey("firms.id"))
    firm = relationship("Firm", back_populates="users")

class Lead(Base):
    __tablename__ = "leads"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"))
    full_name = Column(String, index=True)
    email = Column(String, index=True)
    phone = Column(String, nullable=True)
    status = Column(String, default="new") # new, qualified, disqualified, synced
    case_type = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    source = Column(String, nullable=True)
    is_demo = Column(Integer, default=0)
    qualification_score = Column(Integer, default=0)
    ai_summary = Column(Text, nullable=True)
    case_value_estimate = Column(Float, default=0.0)
    chat_history = Column(Text, nullable=True) # JSON of messages
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    external_crm_id = Column(String, nullable=True)
    sync_status = Column(String, default="Not Synced")
    
    firm = relationship("Firm", back_populates="leads")
    documents = relationship("Document", back_populates="lead")

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"))
    filename = Column(String)
    file_path = Column(String)
    doc_type = Column(String, nullable=True) # medical_record, transcript, id_card
    analysis_json = Column(Text, nullable=True)
    upload_date = Column(DateTime, default=datetime.datetime.utcnow)
    lead = relationship("Lead", back_populates="documents")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"), nullable=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=True)
    action = Column(String)
    details = Column(Text, nullable=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class Usage(Base):
    __tablename__ = "usage"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"))
    usage_type = Column(String) # document_analysis, voice_minutes, email_intake
    quantity = Column(Float, default=1.0)
    details = Column(Text, nullable=True) # Optional JSON details
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    firm = relationship("Firm", back_populates="usage")

class FirmIntegration(Base):
    __tablename__ = "firm_integrations"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"))
    crm_system = Column(String) # clio, filevine
    api_key = Column(String, nullable=True)
    api_secret = Column(String, nullable=True) # or token
    webhook_url = Column(String, nullable=True)
    is_active = Column(Integer, default=1)
    auto_sync_enabled = Column(Integer, default=0) # 1 to automatically sync new qualified leads
    config_json = Column(Text, nullable=True) # extra settings like field mapping
    firm = relationship("Firm")

class DemoRequest(Base):
    __tablename__ = "demo_requests"
    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String)
    email = Column(String)
    firm_name = Column(String, nullable=True)
    status = Column(String, default="pending")
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class Transcript(Base):
    __tablename__ = "transcripts"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"), nullable=True)
    filename = Column(String, index=True)
    file_path = Column(String)
    upload_date = Column(DateTime, default=datetime.datetime.utcnow)
    status = Column(String, default="uploaded") # uploaded, processing, completed, error
    firm = relationship("Firm")
    facts = relationship("Fact", back_populates="transcript")
    conflicts = relationship("Conflict", back_populates="transcript")
    summaries = relationship("Summary", back_populates="transcript")

class Fact(Base):
    __tablename__ = "facts"
    id = Column(Integer, primary_key=True, index=True)
    transcript_id = Column(Integer, ForeignKey("transcripts.id"))
    witness_name = Column(String)
    date_time = Column(String)
    event_description = Column(Text)
    page_reference = Column(Integer)
    line_reference = Column(Integer)
    transcript = relationship("Transcript", back_populates="facts")

class Conflict(Base):
    __tablename__ = "conflicts"
    id = Column(Integer, primary_key=True, index=True)
    transcript_id = Column(Integer, ForeignKey("transcripts.id"))
    witness_a = Column(String)
    witness_b = Column(String)
    description = Column(Text)
    reasoning = Column(Text)
    severity = Column(String) # High, Medium, Low
    transcript = relationship("Transcript", back_populates="conflicts")

class Summary(Base):
    __tablename__ = "summaries"
    id = Column(Integer, primary_key=True, index=True)
    transcript_id = Column(Integer, ForeignKey("transcripts.id"))
    admissions = Column(Text)
    risks = Column(Text)
    executive_summary = Column(Text)
    transcript = relationship("Transcript", back_populates="summaries")

class MedicalRecord(Base):
    __tablename__ = "medical_records"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"), nullable=True)
    filename = Column(String, index=True)
    file_path = Column(String)
    upload_date = Column(DateTime, default=datetime.datetime.utcnow)
    status = Column(String, default="uploaded") # uploaded, processing, completed, error
    firm = relationship("Firm")
    reports = relationship("MeritReport", back_populates="record")

class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey("leads.id"))
    role = Column(String) # user, assistant
    content = Column(Text)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class Form(Base):
    __tablename__ = "forms"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"))
    title = Column(String)
    fields_json = Column(Text) # JSON of form fields
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class FormResponse(Base):
    __tablename__ = "form_responses"
    id = Column(Integer, primary_key=True, index=True)
    form_id = Column(Integer, ForeignKey("forms.id"))
    data_json = Column(Text) # JSON of submitted data
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)

class KnowledgeBase(Base):
    __tablename__ = "knowledge_base"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"))
    category = Column(String)
    question = Column(String)
    answer = Column(Text)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(Integer, primary_key=True, index=True)
    firm_id = Column(Integer, ForeignKey("firms.id"))
    stripe_invoice_id = Column(String, nullable=True)
    amount = Column(Float)
    currency = Column(String, default="usd")
    status = Column(String) # open, paid, void, uncollectible
    hosted_invoice_url = Column(String, nullable=True)
    invoice_pdf = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class MeritReport(Base):
    __tablename__ = "merit_reports"
    id = Column(Integer, primary_key=True, index=True)
    record_id = Column(Integer, ForeignKey("medical_records.id"))
    chronology = Column(Text)
    negligence_markers = Column(Text)
    standard_of_care_analysis = Column(Text)
    executive_summary = Column(Text)
    record = relationship("MedicalRecord", back_populates="reports")
