import models
from database import engine

print("Creating new tables for MeritScan and DepoLens...")
models.Base.metadata.create_all(bind=engine)
print("Done.")
