from database import SessionLocal
import models

def update_logos():
    db = SessionLocal()
    firms = db.query(models.Firm).filter(models.Firm.branding_logo == None).all()
    for f in firms:
        f.branding_logo = '/branding/logo-main.svg'
        print(f"Updated logo for {f.slug}")
    db.commit()
    db.close()

if __name__ == "__main__":
    update_logos()
