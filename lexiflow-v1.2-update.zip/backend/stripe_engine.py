import os
import stripe
import logging
from typing import Dict, Any, Optional
try:
    from . import models
except ImportError:
    import models

logger = logging.getLogger(__name__)

# Initialize stripe with a placeholder or env var
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

class StripeEngine:
    def __init__(self, api_key: Optional[str] = None):
        if api_key:
            self.api_key = api_key
        else:
            self.api_key = os.getenv("STRIPE_SECRET_KEY")

    def create_products(self) -> Dict[str, str]:
        """
        Create the standard LexiFlow products and prices in Stripe.
        Returns a mapping of internal slugs to Stripe Price IDs.
        """
        if not self.api_key or "sk_test" not in self.api_key:
             return {
                 "subscription": "price_subs_placeholder",
                 "usage": "price_usage_placeholder",
                 "implementation": "price_impl_placeholder"
             }

        stripe.api_key = self.api_key
        
        try:
            # 1. Base Subscription ($299/mo)
            sub_product = stripe.Product.create(
                name="LexiFlow Base Subscription",
                description="Intake Agent + Attorney Dashboard"
            )
            sub_price = stripe.Price.create(
                unit_amount=29900,
                currency="usd",
                recurring={"interval": "month"},
                product=sub_product.id,
            )

            # 2. Usage-based AI ($1/doc)
            usage_product = stripe.Product.create(
                name="LexiFlow AI Document Analysis",
                description="Per document analyzed (Medical records, transcripts, etc.)"
            )
            usage_price = stripe.Price.create(
                unit_amount=100,
                currency="usd",
                recurring={"interval": "month", "usage_type": "metered"},
                product=usage_product.id,
            )

            # 3. Implementation Fee ($1,500)
            impl_product = stripe.Product.create(
                name="LexiFlow Deep CRM Integration",
                description="One-time implementation fee for Clio/Filevine setup"
            )
            impl_price = stripe.Price.create(
                unit_amount=150000,
                currency="usd",
                product=impl_product.id,
            )

            return {
                "subscription": sub_price.id,
                "usage": usage_price.id,
                "implementation": impl_price.id
            }
        except Exception as e:
            logger.error(f"Stripe Product Creation Error: {e}")
            return {}

    def report_usage(self, customer_id: str, subscription_item_id: str, quantity: int = 1):
        """
        Report metered usage to Stripe.
        """
        if not self.api_key:
            return
        
        stripe.api_key = self.api_key
        try:
            stripe.SubscriptionItem.create_usage_record(
                subscription_item_id,
                quantity=quantity,
                timestamp="now",
                action="increment"
            )
        except Exception as e:
            logger.error(f"Stripe Usage Reporting Error: {e}")

    def create_checkout_session(self, customer_id: str, price_id: str, success_url: str, cancel_url: str):
        """
        Create a Stripe Checkout Session for a subscription.
        """
        if not self.api_key:
            return None
            
        stripe.api_key = self.api_key
        try:
            session = stripe.checkout.Session.create(
                customer=customer_id,
                payment_method_types=["card"],
                line_items=[{
                    "price": price_id,
                    "quantity": 1,
                }],
                mode="subscription",
                success_url=success_url,
                cancel_url=cancel_url,
            )
            return session
        except Exception as e:
            logger.error(f"Stripe Checkout Session Error: {e}")
            return None

stripe_engine = StripeEngine()
