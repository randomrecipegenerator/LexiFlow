import json
import datetime
from database import SessionLocal
import models

def seed_data():
    db = SessionLocal()
    
    # 1. Add Clifford Law Firm
    clifford_branding = {
        "primary": "#005941",
        "primary_light": "#008964",
        "secondary": "#c57a55",
        "secondary_light": "#e29e7b",
        "accent": "#cb6942",
        "dark": "#22262B",
        "light_accent": "#8cd8c1",
        "background": "#ffffff",
        "text": "#22262B"
    }
    
    clifford_firm = db.query(models.Firm).filter(models.Firm.slug == "clifford-law").first()
    if not clifford_firm:
        clifford_firm = models.Firm(slug="clifford-law")
        db.add(clifford_firm)
    
    clifford_firm.name = "Clifford Law Offices"
    clifford_firm.branding_logo = "/branding/clifford-law-assets/clifford-law-logo.svg"
    clifford_firm.branding_colors = json.dumps(clifford_branding)
    clifford_firm.plan_status = "active"
    db.flush()
    
    # 2. Add Smith LaCien Firm
    smith_branding = {
        "primary": "#0A4030",
        "primary_dark": "#001D0B",
        "secondary": "#006ba1",
        "secondary_light": "#0693e3",
        "accent": "#004a59",
        "accent_light": "#31cdcf",
        "dark": "#313131",
        "background": "#ffffff",
        "text": "#32373c",
        "highlight": "#00d084"
    }
    
    smith_firm = db.query(models.Firm).filter(models.Firm.slug == "smith-lacien").first()
    if not smith_firm:
        smith_firm = models.Firm(slug="smith-lacien")
        db.add(smith_firm)
        
    smith_firm.name = "Smith LaCien LLP"
    smith_firm.branding_logo = "/branding/smith-lacien-assets/smith-lacien-logo.svg"
    smith_firm.branding_colors = json.dumps(smith_branding)
    smith_firm.plan_status = "active"
    db.flush()
    
    # 3. Add Demo Leads for Clifford Law
    # Check if Boeing lead exists
    boeing_lead = db.query(models.Lead).filter(models.Lead.firm_id == clifford_firm.id, models.Lead.case_type == "Aviation").first()
    if not boeing_lead:
        boeing_lead = models.Lead(
            firm_id=clifford_firm.id,
            full_name="Sarah Jenkins",
            email="s.jenkins@aviation-claims.org",
            phone="312-555-0199",
            case_type="Aviation",
            description="Passenger on Boeing 737 MAX flight. Reported severe engine vibration followed by emergency landing. Diagnosed with severe PTSD and cervical strain.",
            qualification_score=92.0,
            status="Qualified",
            ai_summary="High-priority aviation lead involving Boeing 737 MAX. Passenger witness to engine failure. Clear liability and significant psychological damages. Matches Clifford Law's aviation litigation profile.",
            source="Chat",
            is_demo=1
        )
        db.add(boeing_lead)
    
    # 4. Add Demo Leads for Smith LaCien
    truck_lead = db.query(models.Lead).filter(models.Lead.firm_id == smith_firm.id, models.Lead.case_type == "Trucking Accident").first()
    if not truck_lead:
        truck_lead = models.Lead(
            firm_id=smith_firm.id,
            full_name="Maria Santos",
            email="m.santos88@gmail.com",
            phone="773-555-0421",
            case_type="Trucking Accident",
            description="Multi-vehicle collision involving a commercial semi-truck on I-55. Truck failed to brake in stop-and-go traffic. Suspected logbook violation or driver fatigue.",
            qualification_score=94.5,
            status="Qualified",
            ai_summary="High-value trucking accident on I-55. Commercial liability clear. Injuries include vertebral fracture. Critical: potential Hours of Service (HOS) violation identified by AI analysis.",
            source="Chat",
            is_demo=1
        )
        db.add(truck_lead)

    medmal_lead = db.query(models.Lead).filter(models.Lead.firm_id == smith_firm.id, models.Lead.case_type == "Medical Malpractice").first()
    if not medmal_lead:
        medmal_lead = models.Lead(
            firm_id=smith_firm.id,
            full_name="Todd A. Smith (Scenario)",
            email="todd.scenario@medical-cases.com",
            phone="312-555-9000",
            case_type="Medical Malpractice",
            description="Surgical error during routine gallbladder removal. Permanent nerve damage in right arm. Failure to monitor vitals post-op.",
            qualification_score=88.0,
            status="Qualified",
            ai_summary="Strong medical malpractice lead with documented surgical error and permanent disability. Well-aligned with Smith LaCien's expertise in catastrophic injury.",
            source="Chat",
            is_demo=1
        )
        db.add(medmal_lead)
    
    # 5. Add Demo Users
    clifford_user = db.query(models.User).filter(models.User.email == "demo@cliffordlaw.com").first()
    if not clifford_user:
        clifford_user = models.User(
            email="demo@cliffordlaw.com",
            hashed_password="hashed_password_here",
            full_name="Clifford Demo Attorney",
            firm_id=clifford_firm.id,
            role="attorney"
        )
        db.add(clifford_user)
    
    smith_user = db.query(models.User).filter(models.User.email == "demo@smithlacien.com").first()
    if not smith_user:
        smith_user = models.User(
            email="demo@smithlacien.com",
            hashed_password="hashed_password_here",
            full_name="Smith LaCien Demo Partner",
            firm_id=smith_firm.id,
            role="attorney"
        )
        db.add(smith_user)
    
    db.commit()
    print("Demo data seeded/updated successfully.")
    db.close()

if __name__ == "__main__":
    seed_data()
